// JS Code Start Here

//Global Variable List
var firstName = document.getElementById('fname');
var lastName = document.getElementById('lname');
var father = document.getElementById('father');
var mother = document.getElementById('mother');
var email = document.getElementById('email');
var password = document.getElementById('pass');
var rePassword = document.getElementById('rePass');
var image = document.getElementById('img');
var country = document.getElementById('cou');
var phone = document.getElementById('phone');
var address = document.getElementById('add');



// Submit Notification
function validation() {
	if (firstName.value =="" || lastName.value =="" || father.value =="" || mother.value =="" || email.value =="" || password.value =="" || rePassword.value =="" || country.value =="" || phone.value =="" || addresss.value =="") {
		alert("Fill up all Field on Form");
		return false;
	}
	else {
		alert("Form Submitted Successfully! Thank You");
		return true;
	}
}

function checkCountry() {
	if(country.value.length < 5 || country.value.length > 15){
    	alert("Please Type your correct Country");
    	return false;
  	}
  	else {
  		alert("Type Correct Country Name. Thank You!")
  		return true;
  	}
}

function checkPhone() {
	if(isNaN(phone.value) || phone.value.length != 11){
    	alert("Please Enter valid Phone Number");
    	return false;
  	}
  	else {
  		alert("Type Correct Phone Number. Thank You!");
  		return true;
  	}
}

function checkaddress() {
	if(address.value.length <=15){
    	alert("Please Enter Your Address More Than 10 Characters");
    	return false;
  	}
  	else {
  		alert("Type Correct Address. Thank You!");
  		return true;
  	}
}

function confirmPassword() {
	if(rePassword.value != password.value){
    	alert("Re-Password Not Matching");
    	return false;
  	}
  	else {
  		alert("Re-Password Matching. Thank you!");
  		return true;
  	}
}

function checkEmail() {
	var pattern = /^([a-z\d\.-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/; 
	if (pattern.test(email.value))
  	{
  		alert("Type Correct Email address. Thank You!")
    	return true;
  	}
  	else {
    	alert("You have entered an Invalid Email address!");
    	return false;
  	}
}

function checkPassword() {
	var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})?$/; 
	if (regex.test(password.value))
  	{
  		alert("Type Correct Email address. Thank You!")
    	return true;
  	}
  	else {
    	alert("You have entered an Invalid Email address!");
    	return false;
  	}
}

function fileValidation() {
		
	// Allowing file type 
	var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i; 
			
	if (!allowedExtensions.exec(image.value)) { 
		alert('Invalid file type'); 
		image.value = ''; 
		return false; 
	} 
	else 
	{ 
		alert('This is valid image file');
		return true;
	} 
}

function onlyString() {
	string = /^([A-Z][a-z])?$/;
	if(string.test(firstName.value) || string.test(lastName.value) || string.test(father.value) || string.test(mother.value)) {
		alert("Correct Name Format. Thank you!");
		return true;
	}
	else {
		alert("Invalid Name Format.");
		return false;
	}
}