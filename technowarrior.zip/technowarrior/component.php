<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="description" content="Techno Warrior Website">
    <meta name="keywords" content="HTML, CSS, JavaScript, PHP">
    <meta name="author" content="Alpha 3D">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Component Page</title>

    <!-- OWl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" />

    <!-- CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- Header Top Section Start Here -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="#">Techno Warrior</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="accessories.php">Accessories</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="component.php">Component</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Product</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="buildpc.php">Build PC</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Top Section Ends Here -->

    <!-- Banner Section Start Here -->
    <section class="banner">
        <div class="back-shapes">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="banner-text">
                        <h1>Our awesome product</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <a href="#" class="btn mybtn1">Buy For ৳90,567</a>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="banner-img">
                        <img src="images/banner-img.png" alt="Banner Images">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner Section Ends Here -->

    <!-- Monitor Section Start Here -->
    <section class="monitor-items" id="monitors">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <div class="section-title">
                        <h1>Monitor Items</h1>
                        <p>We have lots of excellent and high quality products</p>
                    </div>
                </div>
            </div>


                <div class="owl-carousel" id="product-carousel">

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/msi.jpg" alt="product">
                                <div class="overlay">
                                    <a href="cart.html" class="btn mybtn1 add-cart">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳19,000</span>
                                    <span class="old-price">৳20,070</span>
                                </div>
                                <h5 class="product-name">MSI Optix G241V 24 inch</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/philips1.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳39,500</span>
                                    <span class="old-price">৳42,320</span>
                                </div>
                                <h5 class="product-name">Philips 328C7QJSG/69 32 Inch</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/asus1.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳17,000</span>
                                    <span class="old-price">৳18,230</span>
                                </div>
                                <h5 class="product-name">Asus VA24DQ 23.8 Inch IPS Frameless</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/asus2.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳9,200</span>
                                    <span class="old-price">৳9,930</span>
                                </div>
                                <h5 class="product-name">ASUS VP228HE 21.5 Inch Gaming Monitor</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/dell1.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳16,000</span>
                                    <span class="old-price">৳17,360</span>
                                </div>
                                <h5 class="product-name">Dell SE2417HGX 24 Inch Gaming Monitor</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/dell2.jpg" alt="product">
                                <div class="overlay">
                                    <a href="cart.html" class="btn mybtn1 add-cart">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳26,500</span>
                                    <span class="old-price">৳28,430</span>
                                </div>
                                <h5 class="product-name">Dell SE2719HR 27 Inch LED Monitor</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/hp1.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳22,000</span>
                                    <span class="old-price">৳23,650</span>
                                </div>
                                <h5 class="product-name">HP Z23n G2 23 Inch FHD Narrow Bezel</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/hp2.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳25,500</span>
                                    <span class="old-price">৳27,560</span>
                                </div>
                                <h5 class="product-name">HP EliteDisplay E243m 23.8 Inch</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/lg1.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳9,700</span>
                                    <span class="old-price">৳10,470</span>
                                </div>
                                <h5 class="product-name">LG 22MN430M-B 21.5 Inch IPS Black</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/monitor/lg2.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳51,000</span>
                                    <span class="old-price">৳54,250</span>
                                </div>
                                <h5 class="product-name">LG 27GN750 27 Inch UltraGear Borderless</h5>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </section>
    <!-- Monitor Section Ends Here -->

    <!-- CPU Cooler Section Start Here -->
    <section class="cpu-cooler-items" id="monitors">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <div class="section-title">
                        <h1>CPU Cooler Items</h1>
                        <p>We have lots of excellent and high quality products</p>
                    </div>
                </div>
            </div>

            <div class="owl-carousel" id="cpu-cooler-carousel">

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/cpu-cooler/thermaltake-ux100.jpg" alt="product">
                                <div class="overlay">
                                    <a href="cart.html" class="btn mybtn1 add-cart">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳1,570</span>
                                    <span class="old-price">৳1,500</span>
                                </div>
                                <h5 class="product-name">Thermaltake UX100 ARGB Lighting Air</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/cpu-cooler/cooler-master-masterliquid.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳12,950</span>
                                    <span class="old-price">৳14,000</span>
                                </div>
                                <h5 class="product-name">Cooler MasterLiquid ML360R</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/cpu-cooler/thermaltake-ux200.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳3,000</span>
                                    <span class="old-price">৳3,150</span>
                                </div>
                                <h5 class="product-name">Thermaltake UX200 ARGB Lighting Air</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/cpu-cooler/corsair-hydro-series-h45.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳4,500</span>
                                    <span class="old-price">৳5,400</span>
                                </div>
                                <h5 class="product-name">Corsair Hydro Series H45</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/cpu-cooler/thermaltake-water.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳7,700</span>
                                    <span class="old-price">৳8,140</span>
                                </div>
                                <h5 class="product-name">Thermaltake Water 3.0 120</h5>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </section>
    <!-- CPU Cooler Section Ends Here -->

    <!-- Power Supply Section Start Here -->
    <section class="power-supply-items" id="power-supply">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <div class="section-title">
                        <h1>Power Supply Items</h1>
                        <p>We have lots of excellent and high quality products</p>
                    </div>
                </div>
            </div>

            <div class="owl-carousel" id="power-supply-carousel">

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/power-supply/thermaltake-550w.jpg" alt="product">
                                <div class="overlay">
                                    <a href="cart.html" class="btn mybtn1 add-cart">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳6,200</span>
                                    <span class="old-price">৳6,620</span>
                                </div>
                                <h5 class="product-name">Thermaltake Smart BX1 550W 80 Plus</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/power-supply/gigabyte-650w.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳5,500</span>
                                    <span class="old-price">৳5,940</span>
                                </div>
                                <h5 class="product-name">Gigabyte P650B 650W 80 Plus</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/power-supply/thermaltake-750w.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳8,000</span>
                                    <span class="old-price">৳8,680</span>
                                </div>
                                <h5 class="product-name">Thermaltake Smart BX1 750W 80 Plus</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/power-supply/cooler-master-450w.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳4,000</span>
                                    <span class="old-price">৳4,290</span>
                                </div>
                                <h5 class="product-name">Cooler Master MWE 450W 80 Plus</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/power-supply/thermaltake-450w.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳3,700</span>
                                    <span class="old-price">৳3,960</span>
                                </div>
                                <h5 class="product-name">Thermaltake W0423RE Litepower 450W</h5>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </section>
    <!-- Power Supply Section Ends Here -->

    <!-- RAM Section Start Here -->
    <section class="ram-items" id="ram">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <div class="section-title">
                        <h1>RAM Items</h1>
                        <p>We have lots of excellent and high quality products</p>
                    </div>
                </div>
            </div>

            <div class="owl-carousel" id="ram-carousel">

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/ram/gskill-8gb-ddr4-4266mhz-silver.jpg" alt="product">
                                <div class="overlay">
                                    <a href="cart.html" class="btn mybtn1 add-cart">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳10,090</span>
                                    <span class="old-price">৳9,500</span>
                                </div>
                                <h5 class="product-name">G.Skill Trident Z Royal 8GB DDR4 4266MHz</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/ram/corsair-8gb-ddr4-3200mhz.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳5,900</span>
                                    <span class="old-price">৳6,400</span>
                                </div>
                                <h5 class="product-name">Corsair Platinum RGB 8GB DDR4 3200MHz</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/ram/gskill-4gb-ddr4-3200-bus.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳3,000</span>
                                    <span class="old-price">৳3,250</span>
                                </div>
                                <h5 class="product-name">G.Skill Trident Z 4GB DDR4 3200 BUS</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/ram/gskill-8gb-ddr4-2400-bus.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳4,000</span>
                                    <span class="old-price">৳4,120</span>
                                </div>
                                <h5 class="product-name">G.Skill Trident Z 8GB DDR4 2400 BUS</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="products-item">
                            <div class="product-img">
                                <img class="img-fluid" src="images/ram/corsair-8gb-ddr4-3200mhz.jpg" alt="product">
                                <div class="overlay">
                                    <a href="#" class="btn mybtn1">Buy Now</a>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-price">
                                    <span class="new-price">৳7,700</span>
                                    <span class="old-price">৳8,140</span>
                                </div>
                                <h5 class="product-name">Corsair Vengeance LPX PRO 8GB DDR4 3200MHz</h5>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </section>
    <!-- RAM Section Ends Here -->

    <!--  -->

    <!-- Optional JavaScript -->

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
    
    <!-- Owl Carasoul JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>
    
    <!-- MY JS -->
    <script src="js/custom.js"></script>
    
    <script type="text/javascript">
        $('#product-carousel').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
            dots:false,
            autoplay:true,
            smartSpeed:1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:4
                }
            }    
        });


        $('#cpu-cooler-carousel').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
            dots:false,
            autoplay:true,
            smartSpeed:1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:4
                }
            }    
        });


        $('#power-supply-carousel').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
            dots:false,
            autoplay:true,
            smartSpeed:1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:4
                }
            }    
        });

        $('#ram-carousel').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
            dots:false,
            autoplay:true,
            smartSpeed:1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:4
                }
            }    
        });

    </script>

</body>

</html>