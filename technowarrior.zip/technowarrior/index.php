<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="description" content="Techno Warrior Website">
    <meta name="keywords" content="HTML, CSS, JavaScript, PHP">
    <meta name="author" content="Alpha 3D">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Home Page</title>

    <!-- OWl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" />

    <!-- CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- Header Top Section Start Here -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="#">Techno Warrior</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="accessories.php">Accessories</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="component.php">Component</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="buildpc.php">Build PC</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="login.php">Sign In</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Top Section Ends Here -->

    <!-- Banner Section Start Here -->
    <section class="home-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-8">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="images/banner1.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="images/banner2.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="images/banner1.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                </div>  
                <div class="col-md-4 col-sm-4">
                    <div class="grid">
                        <a href="#">
                            <img src="images/side-banner1.jpg" alt="">
                        </a>
                    </div>
                    <div class="grid">
                        <a href="#">
                            <img src="images/side-banner2.jpg" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>      
    <!-- Banner Section Ends Here -->

    <!-- Home-product Section Start Here -->
    <section class="product">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4">
                    <div class="product-box">
                        <div class="product-images">
                            <img src="images/laptop/Acer Aspire 3 A315-23 AMD Athlon Silver 3050U 15.6''HD Laptop.jpg" alt="asus monitor">
                            <div class="product-img-hover">
                                <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                        </div>
                            </div>
                        <div class="product-details">
                            <h3>Acer Aspire</h3>
                            <p><i class="fas fa-angle-double-right"></i> AMD Athlon Silver 3050U ( 2.3GHz Up to 3.2GHz )Processor</p>
                            <p><i class="fas fa-angle-double-right"></i> 4GB DDR4 RAM </p>
                            <p><i class="fas fa-angle-double-right"></i> 1 TB 5400 RPM HDD</p>
                            <p><i class="fas fa-angle-double-right"></i> 15.6" HD (1366 x 768) Display</p>   
                            <h3>৳ 36,800</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="product-box">
                        <div class="product-images">
                            <img src="images/laptop/Chuwi Hi10 Air Intel X5 Z8350 10.1-inch Touch Tablet & Notebook.jpg" alt="asus monitor">
                            <div class="product-img-hover">
                                <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                            </div>
                        </div>
                        <div class="product-details">
                            <h3>Chuwi Hi10 Notebook</h3>
                            <p><i class="fas fa-angle-double-right"></i> Intel Atom x5-Z8350 Processor (2M Cache, 1.44 GHz up to 1.92 GHz)</p>
                            <p><i class="fas fa-angle-double-right"></i> 4GB RAM, 64GB Storage</p>
                            <p><i class="fas fa-angle-double-right"></i> 10.1" (1200x1920)IPS Capacitive Screen</p>
                            <p><i class="fas fa-angle-double-right"></i> Dual Camera 2MP</p> 
                            <h3>৳ 22,900</h3>
                        </div>
                    </div>
                </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/laptop/Dell Vostro 14-3401 Core i3 10th Gen 14 HD Laptop With Win 10.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Dell Vostro</h3>
                                <p><i class="fas fa-angle-double-right"></i> Intel Core i3-1005G1 Processor (4MB Cache, up to 3.4 GHz)</p>
                                <p><i class="fas fa-angle-double-right"></i> 4GB DDR4 2666MHz RAM </p>
                                <p><i class="fas fa-angle-double-right"></i> 1TB HDD</p>
                                <p><i class="fas fa-angle-double-right"></i> 14" HD (1366x768) Display</p> 
                                
                                <h3>৳ 43,500</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/laptop/Lenovo IdeaPad S145 Core i3 8th Gen MX110 2GB Graphics 15.6 HD Laptop.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Lenevo Ideapad Laptop</h3>
                                <p><i class="fas fa-angle-double-right"></i> Intel Core i3-8130U Processor (4M Cache, 2.20 GHz up to 3.40 GHz)</p>
                                <p><i class="fas fa-angle-double-right"></i> Resulation: Full HD (1920×1080) </p>
                                <p><i class="fas fa-angle-double-right"></i> Response Time: 5ms</p>
                                <p><i class="fas fa-angle-double-right"></i> Viewing Angle: 178°</p> 
                               
                                <h3>৳ 46,000</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/A4 Tech PK-920H 16 Mega Pixel Full HD Webcam.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>A4 Tech PK-920H Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> Image sensor: 1080p full HD</p>
                                <p><i class="fas fa-angle-double-right"></i> Video quality: up to 2 megapixels </p>
                                <p><i class="fas fa-angle-double-right"></i> 30 fps recording</p>
                                <p><i class="fas fa-angle-double-right"></i> Viewing Angle: 178°</p> 
                                <p><i class="fas fa-angle-double-right"></i> 16 megapixels (4608x3456)</p>
                                <h3>৳ 3,100</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/Havit HV-HN12G Full HD Webcam.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Havit HV-HN12G Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> Focusing method: Autofocus</p>
                                <p><i class="fas fa-angle-double-right"></i> Mage Sensor: CMOS </p>
                                <p><i class="fas fa-angle-double-right"></i> Speed: 30fps/s(VGA)</p>
                                <p><i class="fas fa-angle-double-right"></i> Dynamic pixel: 2mega</p> 
                                
                                <h3>৳ 2,400</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/Logitech 960-001038 Video Conference Cam Connect.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Logitech Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> FLEXIBLE VIDEO ANY WORKPLACE</p>
                                <p><i class="fas fa-angle-double-right"></i> PERFECT FOR SMALL SPACES </p>
                                <p><i class="fas fa-angle-double-right"></i> COMPACT ALL-IN-ONE DESIGN</p>
                                <p><i class="fas fa-angle-double-right"></i> COMPATIBLE WITH MOST VC APPS</p> 
                                
                                <h3>৳ 49,800</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/Logitech BCC950 HD 1080p Camera Video Conference Webcam.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Logitech BCC950 Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> NATURAL SOUND</p>
                                <p><i class="fas fa-angle-double-right"></i> HANDHELD REMOTE CONTROL </p>
                                <p><i class="fas fa-angle-double-right"></i> USB PLUG-&-PLAY CONNECTIVITY</p>
                                <p><i class="fas fa-angle-double-right"></i> QUALITY OPTICS</p> 
                               
                                <h3>৳ 23,000</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/Logitech C525 HD Webcam.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Logitech C525 Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> Processor 1 GHz</p>
                                
                                <p><i class="fas fa-angle-double-right"></i> Response Time: 5ms</p>
                                <p><i class="fas fa-angle-double-right"></i> Viewing Angle: 178°</p> 
                                <p><i class="fas fa-angle-double-right"></i> 512 MB RAM</p>
                                <h3>৳ 4,000</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/camera/Logitech C525 HD Webcam.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Logitech Webcam</h3>
                                <p><i class="fas fa-angle-double-right"></i> Processor 1 GHz</p>
                                <p><i class="fas fa-angle-double-right"></i> 512 MB RAM </p>
                                <p><i class="fas fa-angle-double-right"></i> Response Time: 5ms</p>
                                <p><i class="fas fa-angle-double-right"></i> Viewing Angle: 178°</p> 
                                <p><i class="fas fa-angle-double-right"></i> Contrast Ratio: 100000000:1</p>
                                <h3>৳ 2,000</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/speaker/Havit HV-M36 Bluetooth Speaker Black.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Speker</h3>
                                <p><i class="fas fa-angle-double-right"></i> IPX7 waterproof, high level waterproof.</p>
                                <p><i class="fas fa-angle-double-right"></i> Output power: 4 watts </p>
                                <p><i class="fas fa-angle-double-right"></i> Connectors: AUX IN, Micro Sd</p>
                                <p><i class="fas fa-angle-double-right"></i> Frequency range: 80 Hz - 20 kHz</p> 
                               <p><i class="fas fa-angle-double-right"></i> Contrast Ratio: 100000000:1</p>
                                <h3>৳ 1,500</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/speaker/Havit HV-SK486 USB 2.0 Speaker.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Speker</h3>
                                <p><i class="fas fa-angle-double-right"></i> Frequency: 90 Hz - 20 kHz</p>
                                <p><i class="fas fa-angle-double-right"></i> Impedance : 4Ω
                                </p>
                                <p><i class="fas fa-angle-double-right"></i> Power Output : 3W x 2 (RMS)</p>
                                <p><i class="fas fa-angle-double-right"></i> Operating Voltage: 5V</p> 
                                
                                <h3>৳ 350</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/speaker/Havit SK563 USB RGB Gaming Speaker.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Speker</h3>
                                <p><i class="fas fa-angle-double-right"></i> Connectivity: Wired USB, Channel 2:0</p>
                                <p><i class="fas fa-angle-double-right"></i> Working current: ≤ 80mA </p>
                                <p><i class="fas fa-angle-double-right"></i> Impedance: 64±15%Ω
                                </p>

                                <h3>৳ 7,50</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/speaker/Havit SK705 2.0 USB Speaker.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Speker</h3>
                                <p><i class="fas fa-angle-double-right"></i> Connectivity: Wired USB, Channel 2:0</p>
                                <p><i class="fas fa-angle-double-right"></i> Working current: ≤ 80mA</p>
                                <p><i class="fas fa-angle-double-right"></i> Response Time: 5ms</p>
                                <p><i class="fas fa-angle-double-right"></i> Impedance: 64±15%Ω</p> 
                           
                                <h3>৳ 500</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                        <div class="product-box">
                            <div class="product-images">
                                <img src="images/speaker/Havit SK708 2.0 RGB USB Gaming Speaker.jpg" alt="asus monitor">
                                <div class="product-img-hover">
                                    <a href="#"><i class="fas fa-plus-circle"></i> Add to Cart</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <h3>Speker</h3>
                                <p><i class="fas fa-angle-double-right"></i>Connectivity: Wired USB</p>
                                <p><i class="fas fa-angle-double-right"></i> Working current: ≤ 80mA </p>
                                <p><i class="fas fa-angle-double-right"></i> RImpedance: 64±15%Ω</p>
                                
                                <h3>৳ 600</h3>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
    <!-- Home-Product Section Ends Here -->

    <!-- Footer Section Start Here -->
    <!-- <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <img src="" alt="">
                </div>
                <div class="col-md-3 col-sm-3">
                    <ul class="">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About us</a></li>
                        <li><a href="accessories.php">Accessories</a></li>
                        <li><a href="component.php">Component</a></li>
                        <li><a href="buildpc.php">Build PC</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-3">
                    <address>
                        <h3>Head Office</h3>
                        <p class="com-title">Techno Warrior Limited</p>
                        <p>Kusholi Bhaban, 4th Floor, 238/1 Begum Rokeya Sharani, Agargaon, Dhaka-1207.</p>
                        
                    </address>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h3>Contact Us</h3>
                    <p>Email: <a href="mailto:info@technowarsplus.com">info[at]technowarsplus[dot]com</a></p>
                    <p>
                        <a href="tel:01559026149">+8809604442121</a> 
                        <a href="tel:01559026149">+8801755662121</a>
                    </p>   
                </div>
            </div>
        </div>
    </footer> -->
    <!-- Footer Section Ends Here -->

    <!-- ---------------footer------------- -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <h3>Download Our App</h3>
                <p>Download App for Android Android
                    ios mobile phone.
                </p>
                <div class="app-logo">
                    <a href="#"><img src="images/play-store.png"></a>
                    <a href="#"><img src="images/app-store.png"></a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
               <img src="images/logo.png">
                <p>Our Purpose Is to Sustainably Make the 
                    Pleasures and Benefits of Sports Accessible
                    to the Many.
                </p>
            </div>
            <div class="col-md-3 col-sm-3">
                <h3>Useful Links</h3>
               <ul>
                   <li><a href="index.php">Home</a></li>
                   <li><a href="about.php">About</a></li>
                   <li><a href="accessories.php">Accessories</a></li>
                   <li><a href="component.php">Component</a></li>
                   <li><a href="buildpc.php">Build PC</a></li>
                </ul>
            </div>
            <div class="col-md-2 col-sm-2">
                <h3>Follow Us</h3>
               <ul>
                   <li><a href="http://www.facebook.com">Facebook</a></li>
                   <li><a href="http://www.twitter.com">Twitter</a></li>
                   <li><a href="http://www.instagram.net">Instagram</a></li>
                   <li><a href="http://www.youtube.com">YouTube</a></li>
               </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">Copyright 2020 - ALpha 3D</p>
    </div>
</div>
<!-- Footer Style Ends Here -->

    <!-- Optional JavaScript -->

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
    
    <!-- Owl Carasoul JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>

   
    <!-- MY JS -->
    <script src="js/custom.js"></script>

</body>

</html>