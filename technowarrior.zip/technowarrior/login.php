<?php

include("connection.php");

    if(isset($_POST["submit"]))
    {
        $email = $_POST["email"];
        $password = $_POST["password"];

        $query = "SELECT `email`, `password` FROM `userlist`";
        $result = mysqli_query($conn, $query);

        $row = mysqli_fetch_array($result);
        // while($row =mysqli_fetch_assoc($result))
        // {
            if($row["email"] == $email && $row["password"] == $password) {
                echo("Login Successfully");
            }
            else
            {
                echo("Login Failed");
            }
        // }
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="description" content="Techno Warrior Website">
    <meta name="keywords" content="HTML, CSS, JavaScript, PHP">
    <meta name="author" content="Alpha 3D">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Login Page</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- Login Section Start Here -->
    <section class="login">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="reg-box">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="login-com-info">
                                    <img src="images/logo.png" alt="">
                                    <p>If you are not register.</p> 
                                    <p>Please <a href="registration.php">Register now.</a></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="reg-form">
                                    <h2>Login</h2>
                                    <form action="login.php" method="post">
                                        <div class="form-group">
                                            <label>Email address</label>
                                            <input type="email" class="form-control" placeholder="Type Email ID" name="email">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" placeholder="Type password" name="password">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Login Section Ends Here -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
</body>

</html>