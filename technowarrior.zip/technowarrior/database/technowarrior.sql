-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2020 at 03:27 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `technowarrior`
--

-- --------------------------------------------------------

--
-- Table structure for table `motherboard`
--

CREATE TABLE `motherboard` (
  `no` int(11) NOT NULL,
  `posModel` varchar(200) NOT NULL,
  `mbModel` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `motherboard`
--

INSERT INTO `motherboard` (`no`, `posModel`, `mbModel`) VALUES
(1, 'Intel Pentium Gold G5420', 'Asus B150-PLUS D3 ATX'),
(2, 'Intel Pentium Gold G5420', 'ASUS H110M-C'),
(3, 'Intel Pentium Gold G5420', 'msi H270 Tomahawk Artic'),
(4, 'Intel Pentium Gold G5420', 'msi H110M Gaming');

-- --------------------------------------------------------

--
-- Table structure for table `processor`
--

CREATE TABLE `processor` (
  `no` int(11) NOT NULL,
  `posType` varchar(200) NOT NULL,
  `posModel` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `processor`
--

INSERT INTO `processor` (`no`, `posType`, `posModel`) VALUES
(1, 'Intel', 'Intel Pentium Gold G5420'),
(2, 'AMD', 'AMD Ryzen 3 3200G');

-- --------------------------------------------------------

--
-- Table structure for table `ram`
--

CREATE TABLE `ram` (
  `no` int(11) NOT NULL,
  `mbModel` varchar(200) NOT NULL,
  `ramModel` varchar(200) NOT NULL,
  `ramType` varchar(200) NOT NULL,
  `ramBus` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ram`
--

INSERT INTO `ram` (`no`, `mbModel`, `ramModel`, `ramType`, `ramBus`) VALUES
(1, 'Asus B150-PLUS D3 ATX', 'G.Skill 4GB', 'DDR4', 2400),
(2, 'Asus B150-PLUS D3 ATX', 'Corsair Vengeance 4GB', 'DDR4', 2400),
(3, 'ASUS H110M-C', 'Corsair Vengeance 4GB ', 'DDR4', 2400),
(4, 'ASUS H110M-C', 'G.Skill Ripjaws V', 'DDR4', 2400),
(5, 'msi H270 Tomahawk Artic', 'G.Skill Ripjaws V 8GB', 'DDR4', 2400),
(6, 'msi H270 Tomahawk Artic', 'G.Skill Trident Z 8GB', 'DDR4', 2400),
(7, 'msi H110M Gaming', 'G.Skill Trident Z 8GB ', 'DDR4', 2400);

-- --------------------------------------------------------

--
-- Table structure for table `userlist`
--

CREATE TABLE `userlist` (
  `id` int(200) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlist`
--

INSERT INTO `userlist` (`id`, `fname`, `lname`, `email`, `password`, `mobile`) VALUES
(1, 'Sheikh Faysal', 'Tareque', 'faysalraktim@gmail.com', 'R12345', '01559026149');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `motherboard`
--
ALTER TABLE `motherboard`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `processor`
--
ALTER TABLE `processor`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `ram`
--
ALTER TABLE `ram`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `userlist`
--
ALTER TABLE `userlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `motherboard`
--
ALTER TABLE `motherboard`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `processor`
--
ALTER TABLE `processor`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ram`
--
ALTER TABLE `ram`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userlist`
--
ALTER TABLE `userlist`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
