<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="description" content="Techno Warrior Website">
    <meta name="keywords" content="HTML, CSS, JavaScript, PHP">
    <meta name="author" content="Alpha 3D">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>About us</title>

    <!-- OWl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" />

    <!-- CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- Header Top Section Start Here -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="#">Techno Warrior</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="accessories.php">Accessories</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="component.php">Component</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="buildpc.php">Build PC</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="login.php">Sign In</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Top Section Ends Here -->

    <!-- About us Section Start Here -->
    <section class="about-us">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2"></div>
                <div class="col-md-8 col-sm-8">
                    <div class="about-body">
                        <div class="about-field">
                            <div class="about-title">
                                <h2>Techono Warriors Limited</h2>
                            </div>
                            <div class="about-text">
                                <p>One of the largest retail chain stores for computer product in Bangladesh. Notebook, Desktops, Tablets, PC Components, Camera, Software, Office Equipment are the main products. Besides, Techno provides product related services.We have branches in Dhaka IDB Bhaban, Dhaka Banani, Dhaka Uttara, Dhaka Multiplan Centre, Dhaka Eastern Plus, Chittagong, Bogra, Rangpur, Mymensingh, Barisal Rajshahi and Khulna. This has been possible because of the hard work Techno has done to satisfy their customers. Having the aim to satisfy customers, providing customers with their required products and being true to their moto, “Customers Come First”, has brought Techno to the top of the E-Commerce Site and also is one of the largest electronic  retailer . Star Tech has over 300 employees and is growing more and more, working diligently to fulfill the Main Criteria of Star Tech’s Moto or Vision.</p>
                            </div>
                        </div>
                        <div class="about-field">
                            <div class="about-title">
                                <h2>The Main Goal and Aim</h2>
                            </div>
                            <div class="about-text">
                                <p>We are Techno Warrior and we are here to help you with all your electronic needs. We aim to provide all the requirements of our customers and help them satisfy their needs, wants and desires. We delight in seeing our customers happy and satisfied with our resiliency in providing them with their products. Our complete focus is on the customers. We keep tabs and records on what our customers want, and we try our level best to bring that for them. We are already providing our customers with the delivery system so that they can order online and receive their products from their area. They do not have to travel long distances to get their desired product.</p>
                            </div>
                        </div>
                        <div class="about-field">
                            <div class="about-title">
                                <h2>Customer Satisfaction</h2>
                            </div>
                            <div class="about-text">
                                <p>We have been in the market for a long time and we have come to know what the customers want and desire. We have made chances around our customers so that we will be able to fulfil the desires of each of our customers. We want to improve more and more to be able to give everyone their desired or dreamed products. We are providing online buying opportunities for our customers, providing delivery service for all of our products all over Bangladesh. We provide the best after sells customer service to our customers to make them feel that we do care about their possession and provide them with the best solutions for their problems.</p>
                            </div>
                        </div>
                    </div>  
                </div>
                <div class="col-md-2 col-sm-2"></div>
            </div>
        </div>
    </section>
    <!-- About us Section Ends Here -->

    <!-- ---------------footer------------- -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <h3>Download Our App</h3>
                <p>Download App for Android Android
                    ios mobile phone.
                </p>
                <div class="app-logo">
                    <a href="#"><img src="images/play-store.png"></a>
                    <a href="#"><img src="images/app-store.png"></a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
               <img src="images/logo.png">
                <p>Our Purpose Is to Sustainably Make the 
                    Pleasures and Benefits of Sports Accessible
                    to the Many.
                </p>
            </div>
            <div class="col-md-3 col-sm-3">
                <h3>Useful Links</h3>
               <ul>
                   <li><a href="index.php">Home</a></li>
                   <li><a href="about.php">About</a></li>
                   <li><a href="accessories.php">Accessories</a></li>
                   <li><a href="component.php">Component</a></li>
                   <li><a href="buildpc.php">Build PC</a></li>
                </ul>
            </div>
            <div class="col-md-2 col-sm-2">
                <h3>Follow Us</h3>
               <ul>
                   <li><a href="http://www.facebook.com">Facebook</a></li>
                   <li><a href="http://www.twitter.com">Twitter</a></li>
                   <li><a href="http://www.instagram.net">Instagram</a></li>
                   <li><a href="http://www.youtube.com">YouTube</a></li>
               </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">Copyright 2020 - ALpha 3D</p>
    </div>
</div>
<!-- Footer Style Ends Here -->

    <!-- Optional JavaScript -->

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
    
    <!-- Owl Carasoul JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>
    
    <!-- MY JS -->
    <script src="js/custom.js"></script>

</body>

</html>