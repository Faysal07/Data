<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "technowarrior";

    $conn = mysqli_connect($servername, $username, $password, $db);

    // Add Product 

    if (isset($_POST['upload'])) {
        //Variable Declaration

        $image = $_POST["img"];
        $pname = $_POST["pname"];
        $pdetail = $_POST["pdetails"];
        $pcata = $_POST["pcat"];
        $pserialno = $_POST["pserial"];
        $pammount = $_POST["pamount"];
        
        $sql = "INSERT INTO `productlist`(`proimage`, `proname`, `prodetails`, `procatago`, `proserial`, `proamount`) 
                VALUES ('$image', '$pname', '$pdetail', '$pcata', '$pserialno', '$pammount')";
         
        mysqli_query($conn, $sql);

        // if (move_uploaded_file($image['image']['tmp_name'], $target)) {
        //     $msg = "Image uploaded successfully";
        // }else{
        //     $msg = "Failed to upload image";
        // }
    }
?>