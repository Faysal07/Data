<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Admin Panel</title>

    <link rel="stylesheet" href="css/admin-custom.css">
</head>

<body>
    <!-- Section Start Here -->
    <div class="wrapper">
        <div class="sidebar">
            <h2>Techno</h2>
            <h3>Warrior</h3>
            <ul>
                <li><a href="#"><i class="fas fa-home"></i>Dashboard</a></li>
                <li><a href="add product.html"><i class="fas fa-user"></i>Add Product</a></li>
                <li><a href="#"><i class="fas fa-address-card"></i>Edit Product</a></li>
                <li><a href="#"><i class="fas fa-project-diagram"></i>portfolio</a></li>
                <li><a href="#"><i class="fas fa-blog"></i>Blogs</a></li>
                <li><a href="#"><i class="fas fa-address-book"></i>Contact</a></li>
                <li><a href="#"><i class="fas fa-map-pin"></i>Map</a></li>
            </ul>
            <div class="social_media">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="main_content">
            <div class="header">Welcome!! Have a nice day.</div>
            <div class="info">
                <div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A sed nobis ut exercitationem atque
                    accusamus sit natus officiis totam blanditiis at eum nemo, nulla et quae eius culpa eveniet
                    voluptatibus repellat illum tenetur, facilis porro. Quae fuga odio perferendis itaque alias sint,
                    beatae non maiores magnam ad, veniam tenetur atque ea exercitationem earum eveniet totam ipsam magni
                    tempora aliquid ullam possimus? Tempora nobis facere porro, praesentium magnam provident accusamus
                    temporibus! Repellendus harum veritatis itaque molestias repudiandae ea corporis maiores non
                    obcaecati libero, unde ipsum consequuntur aut consectetur culpa magni omnis vero odio suscipit vitae
                    dolor quod dignissimos perferendis eos? Consequuntur!</div>
                <div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A sed nobis ut exercitationem atque
                    accusamus sit natus officiis totam blanditiis at eum nemo, nulla et quae eius culpa eveniet
                    voluptatibus repellat illum tenetur, facilis porro. Quae fuga odio perferendis itaque alias sint,
                    beatae non maiores magnam ad, veniam tenetur atque ea exercitationem earum eveniet totam ipsam magni
                    tempora aliquid ullam possimus? Tempora nobis facere porro, praesentium magnam provident accusamus
                    temporibus! Repellendus harum veritatis itaque molestias repudiandae ea corporis maiores non
                    obcaecati libero, unde ipsum consequuntur aut consectetur culpa magni omnis vero odio suscipit vitae
                    dolor quod dignissimos perferendis eos? Consequuntur!</div>
                <div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. A sed nobis ut exercitationem atque
                    accusamus sit natus officiis totam blanditiis at eum nemo, nulla et quae eius culpa eveniet
                    voluptatibus repellat illum tenetur, facilis porro. Quae fuga odio perferendis itaque alias sint,
                    beatae non maiores magnam ad, veniam tenetur atque ea exercitationem earum eveniet totam ipsam magni
                    tempora aliquid ullam possimus? Tempora nobis facere porro, praesentium magnam provident accusamus
                    temporibus! Repellendus harum veritatis itaque molestias repudiandae ea corporis maiores non
                    obcaecati libero, unde ipsum consequuntur aut consectetur culpa magni omnis vero odio suscipit vitae
                    dolor quod dignissimos perferendis eos? Consequuntur!</div>
            </div>
        </div>
    </div>
    <!-- Section Ends Here -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
</body>

</html>