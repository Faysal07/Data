<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Admin Add Product</title>

    <link rel="stylesheet" href="css/admin-custom.css">
</head>

<body>

    <!-- Section Start Here -->
    <div class="wrapper">
        <div class="sidebar">
            <h2>Techno</h2>
            <h3>Warrior</h3>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-home"></i>Dashboard</a></li>
                <li><a href="add product.html"><i class="fas fa-user"></i>Add Product</a></li>
                <li><a href="#"><i class="fas fa-address-card"></i>Edit Product</a></li>
                <li><a href="#"><i class="fas fa-project-diagram"></i>portfolio</a></li>
                <li><a href="#"><i class="fas fa-blog"></i>Blogs</a></li>
                <li><a href="#"><i class="fas fa-address-book"></i>Contact</a></li>
                <li><a href="#"><i class="fas fa-map-pin"></i>Map</a></li>
            </ul>
            <div class="social_media">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="main_content">
            <div class="header">Add New Product</div>
            <div class="info">
                <!-- Banner Section Start Here -->
                <div class="banner">
                    <div class="banner-text">
                        <h1>Add New Product for <span class="animated-text"></span></h1>
                    </div>
                </div>
                <!-- Banner Section Ends Here -->
                <!-- ADD Product Form Section Start Here -->
                <div class="add-product-form">
                    <form action="server.php" method="post">
                        <div class="form-group">
                            <label>Add Product Image</label>
                            <input type="file" name="img" required>
                        </div>
                        <div class="form-group">
                            <label>Product Name</label>
                            <input class="form-control" type="text" name="pname" required>
                        </div>
                        <div class="form-group">
                            <label>Product Details</label>
                            <textarea class="form-control" name="pdetails" id="" cols="20" rows="5" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Product Catagories</label>
                            <input class="form-control" type="text" name="pcat" required>
                        </div>
                        <div class="form-group">
                            <label>Product Serial Number</label>
                            <input class="form-control" type="text" name="pserial" required>
                        </div>
                        <div class="form-group">
                            <label>Product Amount</label>
                            <input class="form-control" type="number" name="pamount" required>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Upload" name="upload">
                        </div>
                    </form>
                </div>
                <!-- ADD Product Form Section Ends Here -->
            </div>
        </div>
    </div>
    <!-- Section Ends Here -->

    <!-- Optional JavaScript -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

    <!-- Type JS -->
    <script src="../js/typed.js"></script>
    <!-- Font Awosome -->
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>

    <script src="../js/custom.js"></script>
</body>

</html>