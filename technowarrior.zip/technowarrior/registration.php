<?php
    include("connection.php");

    if(isset($_POST["submit"]))
    {
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $email = $_POST["email"];
        $pass = $_POST["pass"];
        $num = $_POST["number"];


        if($fname!="" && $lname!="" && $email!="" && $pass!="" && $num!="")
        {
            $query= "INSERT INTO `userlist`(`fname`, `lname`, `email`, `password`, `mobile`) VALUES ('$fname', '$lname', '$email', '$pass', '$num')";
            $data = mysqli_query($conn, $query);   
        }

        if($data)
        {
            echo "Successfully";
        }
        else
        {
            echo "failed";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="description" content="Techno Warrior Website">
    <meta name="keywords" content="HTML, CSS, JavaScript, PHP">
    <meta name="author" content="Alpha 3D">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Registration Page</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- Registration Section Start Here -->
    <section class="registration">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="reg-box">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="reg-link-info">
                                    <div class="reg-link">
                                        <h4>Get Started</h4>
                                        <a href="#">Sign in with Google+</a>
                                        <a href="#">Sign in with Twitter</a>
                                        <a href="#">Sign in with Linkedin</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="reg-form">
                                    <h2>Register</h2>
                                    <form action="registration.php" method="post">
                                        <div class="form-group">
                                            <label>First name</label>
                                            <input type="text" class="form-control" placeholder="Enter first name" name="fname">
                                        </div>
                                        <div class="form-group">
                                            <label>Last name</label>
                                            <input type="text" class="form-control" placeholder="Enter last name" name="lname">
                                        </div>
                                        <div class="form-group">
                                            <label>Email address</label>
                                            <input type="email" class="form-control" placeholder="Enter email id" name="email">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" placeholder="Enter password" name="pass">
                                        </div>
                                        <div class="form-group">
                                            <label>Phone number</label>
                                            <input type="text" class="form-control" placeholder="Enter phone number" name="number">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Registration Section Ends Here -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
</body>

</html>