<?php
	
	include("connection.php");

	$posquery = "SELECT `posModel` FROM `processor`";
    $posmodel = mysqli_query($conn, $posquery);

	if(isset($_POST["choose"])){
		echo "string";
	}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Only build Pc</title>
</head>
<body>

	<section class="build-pc">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4"></div>
				<div class="col-md-7 col-sm-7">
					<form action="demoBuildpc.php" method="_POST">
					<table>
						<tr>
							<th>Model Name</th>
						</tr>
						<?php while($rows = mysqli_fetch_array($posmodel)):?>
						<tr>
							<td><?php echo $rows['posModel'];?></td>
						</tr>	
						<?php endwhile;?>
					</table>	
					<button type="get" name="choose">Choose</button>
					</form>
				</div>
				<div class="col-md-1 col-sm-1"></div>
			</div>
		</div>
	</section>
	
</body>
</html>