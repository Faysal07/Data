// JS Code Start Here

//Global Variable List
var firstName = document.getElementById('fname').value;
var lastName = document.getElementById('lname').value;
var father = document.getElementById('father').value;
var mother = document.getElementById('mother').value;
var email = document.getElementById('email').value;
var password = document.getElementById('pass').value;
var rePassword = document.getElementById('rePass').value;
var image = document.getElementById('img').value;
var country = document.getElementById('cou').value;
var phone = document.getElementById('phone').value;
var address = document.getElementById('add').value;


// From Error Notification
// var error_message = document.getElementById("error_message");
// error_message.style.padding = "10px";


// Submit Notification
function validation() {
	if (firstName =="" || lastName =="" || father =="" || mother =="" || email =="" || password =="" || rePassword =="" || country =="" || phone =="" || addresss =="") {
		alert("Fill up all Field on Form");
		return false;
	}
	else {
		alert("Form Submitted Successfully! Thank You");
		return true;
	}
}

function checkCountry() {
	if(country.length < 5 || country.length > 15){
    	alert("Please Type your correct Country");
    	return false;
  	}
  	else {
  		alert("Type Correct Country Name. Thank You!")
  		return true;
  	}
}

function checkPhone() {
	if(isNaN(phone) || phone.length != 11){
    	alert("Please Enter valid Phone Number");
    	return false;
  	}
  	else {
  		alert("Type Correct Phone Number. Thank You!");
  		return true;
  	}
}

function checkaddress() {
	if(address.length <=15){
    	alert("Please Enter Your Address More Than 10 Characters");
    	return false;
  	}
  	else {
  		alert("Type Correct Address. Thank You!");
  		return true;
  	}
}

function confirmPassword() {
	if(rePassword != password){
    	alert("Re-Password Not Matching");
    	return false;
  	}
  	else {
  		alert("Re-Password Matching. Thank you!");
  		return true;
  	}
}

function checkEmail() {
	var pattern = /^([a-z\d\.-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/; 
	var correct = Boolean(email.match(pattern));
	console.log(Boolean(email.match(pattern)));
	if (pattern.test(email))
  	{
  		alert("Type Correct Email address. Thank You!")
    	return true;
  	}
  	else {
    	alert("You have entered an Invalid Email address!");
    	return false;
  	}
}

function fileValidation() {
		
	// Allowing file type 
	var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i; 
			
	if (!allowedExtensions.exec(image)) { 
		alert('Invalid file type'); 
		image.value = ''; 
		return false; 
	} 
	else 
	{ 
		alert('This is valid image file');
		return true;
	} 
}